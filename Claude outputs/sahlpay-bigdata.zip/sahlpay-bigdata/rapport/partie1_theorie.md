# Partie 1 — Architecture Spark et positionnement (1 page maximum)

## 1. Les composants Spark dans notre déploiement

Notre cluster tourne en mode **standalone** avec Docker Compose : un conteneur `spark-master`, deux conteneurs `spark-worker-1` et `spark-worker-2` (2 cœurs et 2 Go chacun), et un conteneur `jupyter` dans lequel on écrit le code PySpark.

- **Driver** : c'est le processus qui exécute notre programme PySpark. Chez nous, il tourne dans le conteneur `jupyter`. Il transforme le code en un graphe de tâches (DAG), le découpe en *stages* et en *tasks*, envoie les tasks aux executors et récupère les résultats (par exemple avec `collect()` ou `show()`). Son interface web est sur le port 4040.
- **Cluster Manager** : c'est le `spark-master` (port 7077, interface sur le port 8080). Il connaît les ressources des workers et attribue des cœurs et de la mémoire à chaque application. Il ne fait aucun calcul sur les données.
- **Workers et Executors** : chaque worker est une machine (ici un conteneur) qui met ses ressources à disposition. Quand notre application démarre, chaque worker lance un **executor** : un processus JVM qui exécute les tasks sur une partie des données et garde en mémoire les données mises en cache. Avec 2 workers × 2 cœurs, `sc.defaultParallelism` vaut **4** : 4 tasks peuvent tourner en même temps.
- **SparkContext** (`sc`) : c'est le point d'entrée du driver vers le cluster. Il se connecte au master (`spark://spark-master:7077`), demande des executors et permet de créer des RDD. La **SparkSession** (`spark`) l'enveloppe et ajoute les DataFrames, le SQL et le streaming.

Le chemin d'une requête est donc : notebook → Driver (`jupyter`) → Cluster Manager (`spark-master`) → Executors (`spark-worker-1/2`) → résultat renvoyé au Driver.

## 2. Deux limites de MapReduce / Hadoop corrigées par Spark

**Limite 1 : les écritures sur disque entre chaque étape.** Dans MapReduce, chaque job écrit son résultat sur HDFS, et le job suivant le relit. Un traitement en plusieurs étapes fait donc beaucoup d'accès disque. Spark garde les résultats intermédiaires **en mémoire** et enchaîne les opérations dans un même DAG.
*Lien avec SahlPay :* pour calculer le montant total, le montant moyen et le top des commerçants sur le même historique de transactions, Spark peut mettre les données en cache (`cache()`) une seule fois et les réutiliser, au lieu de relire le fichier pour chaque calcul.

**Limite 2 : MapReduce ne fait que du batch.** MapReduce traite un fichier complet puis s'arrête. Il ne peut pas suivre un flux de données en continu. Spark propose avec **Structured Streaming** un traitement presque en temps réel (micro-batches), avec le même moteur et la même API que le batch.
*Lien avec SahlPay :* les transactions arrivent en continu depuis Kafka (20 événements par seconde). On doit calculer le taux de rejet par ville sur des fenêtres de 10 minutes. Avec MapReduce, il faudrait relancer un job à chaque fois. Avec Spark, une seule requête de streaming met à jour les indicateurs au fil de l'eau.

*(Autre limite possible : l'API MapReduce est bas niveau et verbeuse — une jointure demande beaucoup de code Java. Spark offre des API haut niveau en Python, SQL et Scala, plus des bibliothèques intégrées comme GraphX pour l'analyse de graphes de la Partie 6.)*
