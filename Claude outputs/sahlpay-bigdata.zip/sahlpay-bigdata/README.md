# SahlPay — Plateforme Big Data (Écosystème Big Data 2, EMSI)

Chaîne analytique : `producer.py` → Kafka → Spark (Structured Streaming) → MinIO (Bronze / Silver / Gold) → GraphX / GraphFrames → tableau de bord.

## Versions

| Composant | Version | Image Docker |
|---|---|---|
| Spark | 3.5.8 (Scala 2.12, Java 17, Python 3) | `spark:3.5.8-scala2.12-java17-python3-ubuntu` |
| Kafka | 3.9.1, mode KRaft | `apache/kafka:3.9.1` |
| MinIO | dernière version communautaire | `cgr.dev/chainguard/minio` |
| Jupyter | JupyterLab 4, construit sur l'image Spark | `./jupyter/Dockerfile` |
| hadoop-aws (S3A) | 3.3.4 | via `spark.jars.packages` |
| spark-sql-kafka | 3.5.8 | via `spark.jars.packages` |
| delta-spark | 3.3.2 | via `spark.jars.packages` |

Les packages Spark sont déclarés dans `jupyter/spark-defaults.conf`. Ils sont téléchargés au premier lancement d'une SparkSession, puis gardés dans le volume `ivy-cache`.

## Prérequis

- Docker Desktop (Windows : backend WSL 2).
- Au moins 8 Go de RAM donnés à Docker (16 Go conseillés).

## Lancement

```powershell
docker compose up -d --build
docker compose ps
```

`kafka-init` et `minio-init` créent le topic `transactions` (3 partitions) et le bucket `lake`, puis s'arrêtent. C'est normal qu'ils soient en état `Exited (0)`.

| Interface | Adresse | Identifiants |
|---|---|---|
| Spark Master UI | http://localhost:8080 | — |
| Spark Workers | http://localhost:8081, http://localhost:8082 | — |
| Spark UI de l'application (DAG) | http://localhost:4040 | — |
| JupyterLab | http://localhost:8888 | pas de mot de passe |
| Console MinIO | http://localhost:9001 | `minioadmin` / `minioadmin123` |

Depuis les conteneurs : Kafka = `kafka:9092`, MinIO = `http://minio:9000`.
Depuis le PC (ex. `producer.py` lancé hors Docker) : Kafka = `localhost:9094`.

## Commandes utiles

```powershell
# Vérifier le topic
docker compose exec kafka /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --describe --topic transactions

# Lister le lac (capture obligatoire : couches Bronze / Silver / Gold)
docker compose run --rm mc ls --recursive local/lake/

# Lancer producer.py dans le conteneur Jupyter
docker compose exec jupyter python3 producer/producer.py --mode file --n 50000

# Consumer groups (Partie 5)
docker compose exec kafka /opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server localhost:9092 --all-groups --describe

# Arrêter sans perdre les données Kafka / MinIO
docker compose stop
```

> `docker compose down` supprime le conteneur Kafka et donc les messages du topic. Les données MinIO restent, car elles sont dans un volume. Utiliser `docker compose stop` pour faire une pause.

## Structure du dépôt

```
docker-compose.yml
jupyter/            Dockerfile + spark-defaults.conf
notebooks/          partie1_cluster.ipynb … partie5
graphframes/        Partie 6 (PySpark)
graphx/             Partie 6 (Scala)
producer/           producer.py (fourni)
data/               merchants.json, transactions_history.jsonl (non versionnés)
rapport/            texte du rapport + captures/
```

## Avancement

| Partie | Responsable | État |
|---|---|---|
| 1. Cluster | A | en cours |
| 2. RDD | B | à faire |
| 3. DataFrames / SQL | C | à faire |
| 4. Streaming | A | à faire |
| 5. Production | B | à faire |
| 6. Graphes | C | à faire |
